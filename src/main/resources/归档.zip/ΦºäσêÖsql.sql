
平台注册地址编码校验 结果等于0
     select count(*) from(
select distinct district  from t_submit_platform_base_info where subject_no='100000450')

平台机构或者公司编码校验  结果必须等于0

select count(case when business_license =null and unified_code =null then 1 else null end ) from t_submit_platform_base_info  where subject_no='100000450'
select business_license,unified_code from t_submit_platform_base_info  where subject_no='100000450'

借款人地址编码校验  结果等于0
select count(*) from(
select distinct district from t_submit_borrower_newlys)  //

判断出借人明细文件中出借人编号是否为空
select *  from T_SUBMIT_LOAN_INFO where subject_no='100000450' and USER_NO is null;


借款人类型为平台用户 机构或者公司编码校验  结果必须等于0


select count(case
               when user_type = 'ORGANIZATION' and business_license = null and
                    unified_code = null then
                1
               else
                null
             end)
  from t_submit_borrower_newlys  where subject_no='100000450'
  
  
  select * from t_submit_borrower_newlys where subject_no='100000450'


代偿人 机构或者公司编码校验   结果等于0
select count(case
               when  business_license = null and
                    unified_code = null then
                1
               else
                null
             end)
  from t_submit_compary where  subject_no='100000450'
  
  标的期限为0占比统计  
  
  select count(case
               when project_period = 0 then
                1
               else
                null
             end) / count(*)
  from t_submit_project_base_info
 where subject_no = '100000356'

 
 标的记录与放款明细校验   ******* 验证标的是否存在出借明细，查到的结果是不存在出借记录的标的
 
 select *
    from t_submit_project_base_info
   where project_no not in
         (select p.project_no
            from t_submit_loan_info l
           inner join t_submit_project_base_info p on l.platform_no =
                                                      p.platform_no
                                                  and l.project_no =
                                                      p.project_no
           where p.subject_no = '100000450')
           and subject_no='100000450'
判断标的的个数和出借人所出借的标的是否相等，结果最好一致

select count(*)
from (
    (
      select
        PLATFORM_NO,
        PROJECT_NO,
        count(PROJECT_NO)
      from T_SUBMIT_PROJECT_BASE_INFO
      where SUBJECT_NO = '100000356'
      group by PLATFORM_NO, PROJECT_NO) a left join

    (select
       PLATFORM_NO,
       PROJECT_NO,
       count(PROJECT_NO)
     from T_SUBMIT_LOAN_INFO
     where SUBJECT_NO = '100000356'
     group by PLATFORM_NO, PROJECT_NO) b on a.PLATFORM_NO = b.PLATFORM_NO and a.project_no = b.project_no);
----------------------------------------------
select count(*)
from (
    (
      select
        PLATFORM_NO,
        PROJECT_NO,
        count(PROJECT_NO)
      from T_SUBMIT_PROJECT_BASE_INFO
      where SUBJECT_NO = '100000356'
      group by PLATFORM_NO, PROJECT_NO) a inner join

    (select
       PLATFORM_NO,
       PROJECT_NO,
       count(PROJECT_NO)
     from T_SUBMIT_LOAN_INFO
     where SUBJECT_NO = '100000356'
     group by PLATFORM_NO, PROJECT_NO) b on a.PLATFORM_NO = b.PLATFORM_NO and a.project_no = b.project_no);

出借明细与标的个数的数量比对

	              select count(*) from t_submit_project_base_info where subject_no='100000450'

 标的金额与放款本机汇总及还款本金汇总一致的个数   结果最好大于0
 
 
 1汇总

 select count(*)
  from ((select platform_no, project_no, sum(amount) amount
           from t_submit_loan_info
          where subject_no = '100000450'
          group by project_no, platform_no) a inner join
       
        (select platform_no, project_no, sum(amount) amount
           from t_submit_repay_info
          where subject_no = '100000450'
          group by project_no, platform_no) b on
        a.platform_no = b.platform_no and a.project_no = b.project_no and
        a.amount = b.amount inner join
       
        (select platform_no, project_no, total_loan_money
           from t_submit_project_base_info
          where subject_no = '100000450') c on
        a.platform_no = c.platform_no and a.project_no = c.project_no and
        a.amount = c.total_loan_money)

 2代偿人
 

 select count(*)
  from ((select platform_no, project_no, sum(amount) amount
           from t_submit_loan_info
          where subject_no = '100000450'
          group by project_no, platform_no) a inner join
       
        (select platform_no, project_no, sum(amount) amount
           from t_submit_repay_info
          where subject_no = '100000450' and compary_user_no is not null
          group by project_no, platform_no) b on
        a.platform_no = b.platform_no and a.project_no = b.project_no and
        a.amount = b.amount inner join
       
        (select platform_no, project_no, total_loan_money
           from t_submit_project_base_info
          where subject_no = '100000450') c on
        a.platform_no = c.platform_no and a.project_no = c.project_no and
        a.amount = c.total_loan_money)
3借款人

select count(*)
  from ((select platform_no, project_no, sum(amount) amount
           from t_submit_loan_info
          where subject_no = '100000356'
          group by project_no, platform_no) a inner join
       
        (select platform_no, project_no, sum(amount) amount
           from t_submit_repay_info
          where subject_no = '100000356' and compary_user_no is  null
          group by project_no, platform_no) b on
        a.platform_no = b.platform_no and a.project_no = b.project_no and
        a.amount = b.amount inner join
       
        (select platform_no, project_no, total_loan_money
           from t_submit_project_base_info
          where subject_no = '100000356') c on
        a.platform_no = c.platform_no and a.project_no = c.project_no and
        a.amount = c.total_loan_money)
 
 
代偿人 比代偿记录多的人数  结果大于等于0   ***

select s - z
  from (select count(*) s
           from (select distinct platform_no, user_no from t_submit_compary)),
        (select count(*) z
           from (select distinct platform_no, compary_user_no
                   from t_submit_repay_info
                  where compary_user_no is not null
                    and subject_no = '100000356'))
 
 -------------------------------------------


统计还款记录中的代偿人不在代偿人文件中的个数    结果显示没有代偿人信息的代偿记录
select *
  from ((select platform_no, compary_user_no
           from (select distinct platform_no, compary_user_no
                   from t_submit_repay_info
                  where subject_no = '100000450'
                    and compary_user_no is not null)) a left join
        (select distinct platform_no, user_no
           from t_submit_compary
          where subject_no = '100000450') b on
        a.platform_no = b.platform_no and a.compary_user_no = b.user_no) where user_no is null
 
交易量等于放款交易汇总等于借款人交易汇总的平台个数   结果大于0


 select count(case when borrmoney=pjmoney and pjmoney=inmoney  then 1 else null end ) from 

(select borpt,borrmoney,pjmoney,inmoney  from (

       (select platform_no borpt, sum(total_ioan_amount) borrmoney
         from t_submit_borrower_newlys
        where subject_no = '100000450' 
        group by platform_no) a left join 
        (
      select platform_no pjpt,sum(total_loan_money) pjmoney from t_submit_project_base_info where subject_no='100000450' group by platform_no ) b on a.borpt=b.pjpt
      left join ( 
      
      select  platform_no inpt,sum(i.amount) inmoney from t_submit_loan_info i where subject_no='100000450' group by platform_no) c on a.borpt =c.inpt )
      
      )

平台待还量等于放款金额汇总减去还款金额汇总减去代偿金额汇总的个数 结果大于0


select count(case when bm-nonmoney=0 then 1 else null end) from    
    (  select   lopt,(inmoney-nvl(repmoney,0)-nvl(dcmoney,0)) bm  from (
      select lopt,inmoney,repmoney ,dcmoney from (
     ( select platform_no lopt, sum(amount) inmoney
        from t_submit_loan_info 
      where subject_no = '100000356'  group by platform_no  ) a left join (
       
       
       select platform_no bpt, nvl(sum(b.amount),0) repmoney
         from t_submit_repay_info b
        where subject_no = '100000356' and compary_user_no is null
        group by platform_no) b on a.lopt =b.bpt left join (
        
           
       select platform_no compt, nvl(sum(b.amount),0) dcmoney
         from t_submit_repay_info b
        where subject_no = '100000356' and compary_user_no is not null
        group by platform_no ) c on a.lopt =c.compt ) ) ) a  left join (
        select platform_no ,sum(b.non_repayment_amount) nonmoney from t_submit_borrower_newlys b where subject_no='100000356'  group by platform_no
      
        ) b on a.lopt=b.platform_no 

 
------------------------------------------ 

  
校验存在标的是否都存在出借明细

select count(*)
  from t_submit_project_base_info
 where project_no in
       (
        
        select project_no1
          from ((select platform_no, project_no project_no1
                    from t_submit_project_base_info where subject_no='13213131') a inner join
                 (select platform_no, project_no from t_submit_loan_info where subject_no='132132131321') b on
                 a.platform_no = b.platform_no and a.project_no1 = b.project_no))





借款人借款次数与标的数的对比，展示的结果为出借次数与实际标的个数相同的数量
select count(*)
  from (
        
        select *
          from ((select platform_no, user_no, total_borrowing_times cishu
                    from t_submit_borrower_newlys
                   where subject_no = '100000356') a left join
                 (select platform_no, user_no, count(*) cishu2
                    from t_submit_project_base_info
                   where subject_no = '100000356'
                   group by platform_no, user_no) b on
                 a.platform_no = b.platform_no and a.user_no = b.user_no)
        
        ) c
 where c.cishu = c.cishu2
 


 select count(*) from t_submit_borrower_newlys where subject_no='100000356'


统计有标的的借款人个数和没有标的的借款人个数




select count(*)
from T_SUBMIT_BORROWER_NEWLYS b inner join T_SUBMIT_PROJECT_BASE_INFO p
    on b.PLATFORM_NO = p.PLATFORM_NO and b.USER_NO = p.USER_NO
where b.SUBJECT_NO = '100000450' union all 
select count(*) from T_SUBMIT_BORROWER_NEWLYS where SUBJECT_NO='100000450';

------------------统计没有标的的借款人-----------------------------


select *
from T_SUBMIT_BORROWER_NEWLYS
where SUBJECT_NO = '100000450' and USER_NO not in (
  select p.USER_NO
  from T_SUBMIT_BORROWER_NEWLYS b inner join T_SUBMIT_PROJECT_BASE_INFO p
      on b.PLATFORM_NO = p.PLATFORM_NO and b.USER_NO = p.USER_NO
  where b.SUBJECT_NO = '100000450');
------------------统计没有标的的借款人-----------------------------


-----------------统计没有借款人的标的-------------------------------

select *
from T_SUBMIT_PROJECT_BASE_INFO
where SUBJECT_NO = '100000450' and USER_NO not in (
  select p.USER_NO
  from T_SUBMIT_BORROWER_NEWLYS b inner join T_SUBMIT_PROJECT_BASE_INFO p
      on b.PLATFORM_NO = p.PLATFORM_NO and b.USER_NO = p.USER_NO
  where b.SUBJECT_NO = '100000450');

-----------------统计没有借款人的标的-------------------------------


-----------------统计还款记录中是否存在多余的数据-----------------------------


select a.PROJECT_NO,a.USER_NO,a.PLATFORM_NO,a.lo,b.rep,a.SUBJECT_NO
from

  (select
     PLATFORM_NO,
     USER_NO,
     PROJECT_NO,
     sum(AMOUNT) lo,
    SUBJECT_NO
   from T_SUBMIT_LOAN_INFO
   group by PLATFORM_NO, USER_NO, PROJECT_NO,SUBJECT_NO) a inner join

  (select
     platform_no,
     USER_NO,
     PROJECT_NO,
     sum(AMOUNT) rep,
    SUBJECT_NO
   from T_SUBMIT_REPAY_INFO
   group by platform_no, USER_NO, PROJECT_NO,SUBJECT_NO) b
    on a.PROJECT_NO = b.PLATFORM_NO and a.PROJECT_NO = b.PROJECT_NO and a.USER_NO = b.USER_NO and a.SUBJECT_NO=b.SUBJECT_NO
  
where a.SUBJECT_NO = '100000356';


select count(*) from T_SUBMIT_REPAY_INFO where SUBJECT_NO='100000356';

-----------------统计还款记录中是否存在多余的数据-----------------------------






--------------------统计投资人中的充值和体现金额字段是否为0--------------------


select *
from T_SUBMIT_INVESTOR_BASE_INFO
where SUBJECT_NO = '100000356' and RECEIVED_PAYMENTS_AMOUNT = 0 and WITHDRAW_AMOUNT = 0
order by store_time desc

--------------------统计投资人中的充值和体现金额字段是否为0--------------------


在所有标的存在出借明细的前提下 去校验标的的总投资人数与出借标的人数的汇总是否一致  ，sql最终正确结果不为空

select *
  from ((select platform_no, project_no, sum(total_investment)cishu1
           from t_submit_project_base_info
          where subject_no = '100000450'
          group by platform_no, project_no) a inner join
        (select platform_no, project_no, count(project_no) cishu2
           from t_submit_loan_info
          where subject_no = '100000450'
          group by platform_no, project_no) b on
        a.platform_no = b.platform_no and a.project_no = b.project_no) where cishu1-cishu2!=0














  ---------------------------------------------------------------------
  
  标的的实际放款金额与借款人的借款金额 按照标的对比，相等的个数
  select count(*)
    from t_submit_project_base_info b
    left join (select project_no, sum(amount) lmoney
                 from t_submit_loan_info
                group by project_no) c on b.project_no = c.project_no
                                      and c.lmoney = b.total_loan_money
   where b.subject_no = '100000500'



   校验标的期限，人工识别 去boss后台查询小于30的标的

select * from t_submit_project_base_info where subject_no='100000450' and project_period <30



---------------------------------------

必须执行
借款金额和标的金额，借款次数和标的个数 ，两个结合在一起使用

select *
from (
    (select
       PLATFORM_NO,
       USER_NO,
       sum(TOTAL_IOAN_AMOUNT) br
     from T_SUBMIT_BORROWER_NEWLYS
     group by PLATFORM_NO, USER_NO) a inner join (

                                                   select
                                                     PLATFORM_NO,
                                                     USER_NO,
                                                     sum(TOTAL_LOAN_MONEY) pj
                                                   from T_SUBMIT_PROJECT_BASE_INFO
                                                   group by PLATFORM_NO, USER_NO) b
      on a.PLATFORM_NO = b.PLATFORM_NO and b.USER_NO = a.USER_NO) where br!=pj;



select *
  from (

        select *
          from ((select platform_no, user_no, total_borrowing_times cishu
                    from t_submit_borrower_newlys
                   where subject_no = '100000356') a left join
                 (select platform_no, user_no, count(*) cishu2
                    from t_submit_project_base_info
                   where subject_no = '100000356'
                   group by platform_no, user_no) b on
                 a.platform_no = b.platform_no and a.user_no = b.user_no)

        ) c
 where c.cishu != c.cishu2;



---------------------

标的的投资人数，标的金额和出借人的出借次数和出借金额 比对

select *
  from ((select platform_no, project_no, sum(total_investment)cishu1,TOTAL_LOAN_MONEY
           from t_submit_project_base_info
          where subject_no = '100000400'
          group by platform_no, project_no,TOTAL_LOAN_MONEY) a inner join
        (select platform_no, project_no, count(project_no) cishu2,sum(amount) rep
           from t_submit_loan_info
          where subject_no = '100000400'
          group by platform_no, project_no) b on
        a.platform_no = b.platform_no and a.project_no = b.project_no) where cishu1-cishu2!=0 and TOTAL_LOAN_MONEY-rep!=0;